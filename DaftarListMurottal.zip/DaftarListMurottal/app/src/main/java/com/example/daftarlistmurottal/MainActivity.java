package com.example.daftarlistmurottal;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    int i;

    public void onClick(View view){
        ImageView img=(ImageView) findViewById(R.id.img);
        if (i == 1){
            i=2;
            img.setImageResource(R.drawable.mobil2);

        }else{
            i=1;
            img.setImageResource(R.drawable.mobil1);
        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
